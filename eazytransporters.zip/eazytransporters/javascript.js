

function closeMenu()
{
    document.getElementById('check').click();
}